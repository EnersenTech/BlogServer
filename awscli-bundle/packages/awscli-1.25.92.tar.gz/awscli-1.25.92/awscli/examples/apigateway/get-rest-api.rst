**To get information about an API**

Command::

  aws apigateway get-rest-api --rest-api-id 1234123412

Output::

  {
      "name": "myAPI", 
      "id": "o1y243m4f5", 
      "createdDate": 1453416433
  }
